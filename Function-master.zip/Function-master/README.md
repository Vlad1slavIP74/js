# Functions
Functions as a method to raise level of code abstraction
